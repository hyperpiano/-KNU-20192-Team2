package Person;

public abstract class Employee {
	private String id;
	private String name;
	private String depart;
	private String PhoneNum;
	private String Address;
	private String Mail;
	private double Salary;
	private String Position;
	private double Scores;
	private String Manager;
	protected String type;		// SW Developer, SW Tester, Staff 

	public Employee(String id,String Name, String Department, String PhoneNum, String Address,
			String Mail, double Salary, String Position, double Scores) {
		this.id= id;
		this.name = Name;
		this.depart = Department;
		this.PhoneNum = PhoneNum;
		this.Address = Address;
		this.Mail = Mail;
		this.Salary = Salary;
		this.Position = Position;
		this.Scores = Scores;
		this.Manager = " ";
	}

	public String getId() {
		return this.id;
	}
	public void setId(String employeeID) {
		this.id = employeeID;
	}

	
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	

	public String getDepart() {
		return this.depart;
	}
	public void setDepart(String department) {
		this.depart = department;
	}

	
	public String getPhoneNum() {
		return this.PhoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.PhoneNum = phoneNum;
	}

	
	public String getAddress() {
		return this.Address;
	}
	public void setAddress(String address) {
		this.Address = address;
	}

	
	public String getMail() {
		return this.Mail;
	}
	public void setMail(String mail) {
		this.Mail = mail;
	}

	
	public double getSalary() {
		return this.Salary;
	}
	public void setSalary(double salary) {
		this.Salary = salary;
	}

	
	public String getPosition() {
		return this.Position;
	}
	public void setPosition(String position) {
		this.Position = position;
	}

	
	public double getScores() {
		return this.Scores;
	}
	public void setScores(double scores) {
		this.Scores = scores;
	}

	public String getManager() {return this.Manager;}
	public void setManager() {this.Manager = "O";}

	public String getType() {return this.type;}
	public void setType(String type) {this.type = type;}

	public String toString() {
		return this.id + "/" + this.name + "/" + this.depart + "/" + this.type + "/" + this.Manager;
	}
}