package Person;
public class SW_Developer extends Employee {
	public SW_Developer(String id, String name, String depart,String PhoneNum,String Address,String Mail,double Salary,String position,double score) {
		super(id, name, depart,PhoneNum,Address,Mail,Salary, position,score);
		this.type = "SW Developer";
	}
}
