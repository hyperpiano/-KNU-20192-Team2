package Person;
public class Staff extends Employee {
	public Staff(String id, String name, String depart,String PhoneNum,String Address,String Mail,double Salary,String position,double score) {
		super(id, name, depart,PhoneNum,Address,Mail,Salary, position,score);
		this.type = "Staff";
	}
}
